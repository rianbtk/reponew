<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentTeacher extends Model
{
  protected $table='Teachers';

  public $primaryKey='id';
}
